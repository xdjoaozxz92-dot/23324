# AI Texture Pack Generator (mod Geode para GD 2.2081)

Mod que cria Texture Packs automaticamente com IA. Alvo: **Geometry Dash 2.2081 + Geode v5.x (Windows)**.

## Estado desta entrega (leia primeiro)

| Parte | Estado |
|---|---|
| Núcleo de imagem/tema (`ImageOps`, `PackBuilder`) | Compilado com g++ e **testado** (2 suítes, ver abaixo) |
| Código Geode (`main.cpp`, `AIPopup.cpp`, `ThemeClient.cpp`) | Escrito conforme a documentação do Geode v5, **NÃO compilado nem executado** |
| Arquivo `.geode` | **NÃO gerado aqui.** Compilar mod Geode exige MSVC/Windows SDK; o sandbox onde isto foi feito não alcança os servidores da Microsoft. O `.geode` sai do passo "Como gerar o .geode" abaixo |

Como o código Geode nunca passou por um compilador, é provável que o primeiro build
aponte ajustes pequenos de API. O workflow de CI mostra o erro exato.

## Como gerar o .geode (caminho mais fácil: GitHub Actions)

1. Crie um repositório no GitHub e envie o conteúdo desta pasta (a raiz do repo deve ter `mod.json`).
2. Aba **Actions → Build .geode → Run workflow**.
3. Ao terminar, baixe o artefato **Build Output**: dentro está `aimodgen.ai-texture-packs.geode`.

### Alternativa: build local no Windows
1. Instale Visual Studio (carga "Desenvolvimento para desktop com C++"), CMake e o [Geode CLI](https://docs.geode-sdk.org/getting-started/geode-cli).
2. `geode config setup` e `geode sdk install` (se ainda não tiver o SDK).
3. Na pasta do projeto: `geode build`. O `.geode` aparece em `build/`.

## Instalar
Copie o `.geode` para `<pasta do GD>\geode\mods\` e abra o jogo (ou use o botão de instalar no menu de mods do Geode).
O mod depende do **Texture Loader** (`geode.texture-loader`), que o Geode instala junto.

## Usar
1. Mods → AI Texture Pack Generator → Configurações: escolha o provedor e cole a **chave de API**.
   - `anthropic` (padrão, modelo `claude-haiku-5-5`): só tema/cores.
   - `openai` (ou API compatível via *URL base*): tema + imagem de fundo opcional.
2. Menu principal → botão rosa **AI** → descreva o tema → **Gerar pack**.
3. Abra o **Texture Loader**, arraste o pack novo para o lado direito e toque em **Apply**.

Os packs ficam em `geode/config/geode.texture-loader/packs/<nome-do-tema>/`.

## Como funciona
1. A IA devolve JSON com `name`, `palette`, `hue_shift`, `saturation`, `brightness`, `gradient_strength`, `image_prompt`.
2. O mod lê as texturas originais de `<GD>/Resources` (nunca modifica os originais), rotaciona matiz, ajusta saturação/brilho e mistura com um *gradient map* da paleta, preservando o alpha.
3. Para cada textura, trata as variações `-uhd`, `-hd` e sem sufixo separadamente (os layouts das spritesheets ficam idênticos aos originais).
4. Escreve `pack.json` + `pack.png` no formato do Texture Loader.

Escopo padrão: `GJ_gradientBG`, `game_bg_01..20_001`, `groundSquare_01..10_001`.
Com **Pack completo**: também `GJ_GameSheet`, `02`, `03`, `04`, `Glow` e `GJ_LaunchSheet`.
Nomes que não existirem na sua instalação são simplesmente ignorados.

## Limitações conhecidas
- **Só Windows** na v0.1 (leitura direta de `Resources`; no Android os recursos ficam dentro do APK).
- O GD **tinge fundos e chão em tempo de execução** com as cores do nível, então a recoloração neles pode ficar sutil. O efeito mais visível costuma vir das spritesheets (modo completo) e do menu.
- Nunca foi testado dentro do jogo: o resultado visual real e a lista de nomes de textura precisam de validação sua.
- A chave de API é salva em texto puro nas configurações do mod. O texto do tema é enviado ao provedor escolhido (pode haver custo).
- Imagens geradas por IA: confira os termos do provedor antes de publicar um pack.

## Testes do núcleo (rodam em qualquer g++)
```
g++ -std=c++20 -O2 -Isrc tests/test_imageops.cpp src/ImageOps.cpp src/lodepng.cpp -o /tmp/t1 && /tmp/t1
g++ -std=c++20 -O2 -pthread -Isrc tests/test_packbuilder.cpp src/PackBuilder.cpp src/ImageOps.cpp src/lodepng.cpp -o /tmp/t2 && /tmp/t2
```

## Licenças
`src/lodepng.*` © Lode Vandevenne, licença zlib.
