// Compilar e rodar (sem Geode):
//   g++ -std=c++20 -O2 -Isrc tests/test_imageops.cpp src/ImageOps.cpp src/lodepng.cpp -o /tmp/test_imageops && /tmp/test_imageops
#include "ImageOps.hpp"

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <string>

using namespace aitp;

static int g_fail = 0;
#define CHECK(cond)                                                              \
    do {                                                                         \
        if (!(cond)) {                                                           \
            std::printf("FALHOU %s:%d  %s\n", __FILE__, __LINE__, #cond);        \
            ++g_fail;                                                            \
        }                                                                        \
    } while (0)

static Image solid(unsigned w, unsigned h, uint8_t r, uint8_t g, uint8_t b, uint8_t a) {
    Image im;
    im.w = w;
    im.h = h;
    im.px.resize(size_t(w) * h * 4);
    for (size_t i = 0; i < size_t(w) * h; ++i) {
        im.px[i * 4 + 0] = r;
        im.px[i * 4 + 1] = g;
        im.px[i * 4 + 2] = b;
        im.px[i * 4 + 3] = a;
    }
    return im;
}

int main() {
    // --- cores hex
    RGB c;
    CHECK(parseHexColor("#ff8000", c) && c.r == 255 && c.g == 128 && c.b == 0);
    CHECK(parseHexColor("0f0", c) && c.r == 0 && c.g == 255 && c.b == 0);
    CHECK(!parseHexColor("#12345", c));
    CHECK(!parseHexColor("zzzzzz", c));

    // --- slug
    CHECK(slugify("Neon Cyber City!") == "neon-cyber-city");
    CHECK(slugify("   ") == "ai-pack");
    CHECK(slugify("../../etc/passwd") == "etc-passwd"); // sem path traversal

    // --- json escape
    CHECK(jsonEscape("a\"b\\c\n") == "a\\\"b\\\\c\\n");
    CHECK(jsonEscape(std::string("x\x01y")) == "x\\u0001y");

    // --- base64
    auto b = base64Decode("TWFu");
    CHECK(b.size() == 3 && b[0] == 'M' && b[1] == 'a' && b[2] == 'n');
    auto b2 = base64Decode("TWE=");
    CHECK(b2.size() == 2 && b2[0] == 'M' && b2[1] == 'a');
    auto b3 = base64Decode("TW\nFu");
    CHECK(b3.size() == 3);

    // --- gradiente
    std::vector<RGB> pal = {{0, 0, 0}, {255, 255, 255}};
    CHECK(sampleGradient(pal, 0.f).r == 0);
    CHECK(sampleGradient(pal, 1.f).r == 255);
    CHECK(std::abs(int(sampleGradient(pal, 0.5f).g) - 128) <= 1);

    // --- hue shift: vermelho +120 graus -> verde ; alpha preservado
    Theme t;
    t.hueShift = 120.f;
    t.mix = 0.f;
    Image red = solid(2, 2, 255, 0, 0, 200);
    applyTheme(red, t);
    CHECK(red.px[0] == 0 && red.px[1] == 255 && red.px[2] == 0 && red.px[3] == 200);

    // --- pixel transparente nao muda
    Image clear = solid(1, 1, 10, 20, 30, 0);
    applyTheme(clear, t);
    CHECK(clear.px[0] == 10 && clear.px[1] == 20 && clear.px[2] == 30);

    // --- cinza continua cinza no hue shift puro
    Image gray = solid(1, 1, 100, 100, 100, 255);
    applyTheme(gray, t);
    CHECK(gray.px[0] == 100 && gray.px[1] == 100 && gray.px[2] == 100);

    // --- gradient map total (mix=1) em branco -> ultima cor da paleta
    Theme g;
    g.palette = {{0, 0, 0}, {10, 20, 200}};
    g.mix = 1.f;
    Image white = solid(1, 1, 255, 255, 255, 255);
    applyTheme(white, g);
    CHECK(white.px[0] == 10 && white.px[1] == 20 && white.px[2] == 200);

    // --- clampTheme
    Theme bad;
    bad.hueShift = 9999.f;
    bad.saturation = -5.f;
    bad.brightness = NAN;
    bad.mix = 3.f;
    clampTheme(bad);
    CHECK(bad.hueShift == 180.f && bad.saturation == 0.f && bad.brightness == 1.f && bad.mix == 1.f);

    // --- resize
    Image src = solid(64, 32, 50, 60, 70, 255);
    Image cover = resizeCover(src, 40, 40);
    CHECK(cover.w == 40 && cover.h == 40 && cover.px[0] == 50 && cover.px[2] == 70);
    Image up = resizeBilinear(src, 128, 64);
    CHECK(up.w == 128 && up.h == 64 && up.px[(10 * 128 + 10) * 4 + 1] == 60);

    // --- blend
    Image d = solid(2, 2, 0, 0, 0, 255), s = solid(2, 2, 200, 100, 50, 255);
    blendImage(d, s, 0.5f);
    CHECK(d.px[0] == 100 && d.px[1] == 50 && d.px[2] == 25);

    // --- PNG ida e volta
    Image icon = makeGradientIcon(g, 64);
    std::vector<uint8_t> png;
    std::string err;
    CHECK(encodePng(icon, png, err));
    Image back;
    CHECK(decodePng(png.data(), png.size(), back, err));
    CHECK(back.w == 64 && back.h == 64 && back.px == icon.px);
    Image junk;
    uint8_t garbage[] = {1, 2, 3, 4};
    CHECK(!decodePng(garbage, 4, junk, err) && !err.empty());

    // --- desempenho: folha 4096x4096 (tamanho de GJ_GameSheet-uhd)
    Image sheet = solid(4096, 4096, 120, 200, 40, 255);
    Theme full;
    full.hueShift = 200.f;
    full.saturation = 1.2f;
    full.palette = {{5, 2, 30}, {120, 20, 160}, {250, 60, 180}};
    full.mix = 0.4f;
    applyTheme(sheet, full);
    CHECK(sheet.px[0] != 120);

    // --- gera previa para inspecao visual
    if (const char* out = std::getenv("AITP_PREVIEW")) {
        std::ofstream(out, std::ios::binary).write(reinterpret_cast<char const*>(png.data()), png.size());
    }

    if (g_fail == 0) std::printf("OK: todos os testes passaram\n");
    return g_fail ? 1 : 0;
}
