// Teste de ponta a ponta do PackBuilder com uma pasta "Resources" falsa.
//   g++ -std=c++20 -O2 -Isrc tests/test_packbuilder.cpp src/PackBuilder.cpp src/ImageOps.cpp src/lodepng.cpp -o /tmp/test_packbuilder && /tmp/test_packbuilder
#include "PackBuilder.hpp"

#include <cstdio>
#include <fstream>
#include <sstream>

namespace fs = std::filesystem;
using namespace aitp;

static int g_fail = 0;
#define CHECK(cond)                                                       \
    do {                                                                  \
        if (!(cond)) {                                                    \
            std::printf("FALHOU %s:%d  %s\n", __FILE__, __LINE__, #cond); \
            ++g_fail;                                                     \
        }                                                                 \
    } while (0)

static void writeFakePng(fs::path const& p, unsigned w, unsigned h, uint8_t r, uint8_t g, uint8_t b) {
    Image im;
    im.w = w;
    im.h = h;
    im.px.resize(size_t(w) * h * 4);
    for (size_t i = 0; i < size_t(w) * h; ++i) {
        im.px[i * 4] = r;
        im.px[i * 4 + 1] = g;
        im.px[i * 4 + 2] = b;
        im.px[i * 4 + 3] = (i % 7 == 0) ? 0 : 255; // alguns pixels transparentes
    }
    std::vector<uint8_t> png;
    std::string err;
    encodePng(im, png, err);
    std::ofstream(p, std::ios::binary).write(reinterpret_cast<char const*>(png.data()), png.size());
}

int main() {
    fs::path root = fs::temp_directory_path() / "aitp_test";
    fs::remove_all(root);
    fs::path res = root / "Resources", packs = root / "packs";
    fs::create_directories(res);

    writeFakePng(res / "game_bg_01_001-uhd.png", 256, 128, 120, 120, 120);
    writeFakePng(res / "game_bg_01_001-hd.png", 128, 64, 120, 120, 120);
    writeFakePng(res / "groundSquare_01_001-uhd.png", 128, 128, 200, 100, 50);
    writeFakePng(res / "GJ_GameSheet-uhd.png", 512, 512, 30, 200, 60);

    Theme t;
    t.name = "Neon Cyber City!";
    t.palette = {{5, 2, 30}, {120, 20, 160}, {250, 60, 180}};
    t.hueShift = 90.f;
    t.mix = 0.5f;

    // --- pack basico (sem folhas)
    BuildOptions o;
    o.theme = t;
    o.full = false;
    o.resourcesDir = res;
    o.packsDir = packs;
    auto state = startBuildThread(o);
    while (!state->finished) {}
    CHECK(state->result.ok);
    CHECK(state->result.filesWritten == 3);
    CHECK(state->result.filesFailed == 0);
    CHECK(fs::exists(packs / "neon-cyber-city" / "pack.json"));
    CHECK(fs::exists(packs / "neon-cyber-city" / "pack.png"));
    CHECK(fs::exists(packs / "neon-cyber-city" / "game_bg_01_001-uhd.png"));
    CHECK(!fs::exists(packs / "neon-cyber-city" / "GJ_GameSheet-uhd.png")); // so no modo completo

    // dimensoes preservadas e cor realmente alterada
    {
        std::ifstream f(packs / "neon-cyber-city" / "game_bg_01_001-uhd.png", std::ios::binary);
        std::vector<uint8_t> raw((std::istreambuf_iterator<char>(f)), {});
        Image im;
        std::string err;
        CHECK(decodePng(raw.data(), raw.size(), im, err));
        CHECK(im.w == 256 && im.h == 128);
        CHECK(!(im.px[4] == 120 && im.px[5] == 120 && im.px[6] == 120)); // pixel opaco mudou
        CHECK(im.px[3] == 0);                                           // pixel 0 continua transparente
    }

    // pack.json valido e com nome escapado
    {
        std::ifstream f(packs / "neon-cyber-city" / "pack.json");
        std::stringstream ss;
        ss << f.rdbuf();
        std::string js = ss.str();
        CHECK(js.find("\"textureldr\": \"1.5.0\"") != std::string::npos);
        CHECK(js.find("\"id\": \"aimodgen.neon-cyber-city\"") != std::string::npos);
        CHECK(js.find("Neon Cyber City!") != std::string::npos);
    }

    // --- pack completo + imagem de IA nos fundos
    Image ai;
    ai.w = 64;
    ai.h = 64;
    ai.px.assign(64 * 64 * 4, 255); // branco
    o.full = true;
    o.aiImage = ai;
    o.theme.name = "Full Pack";
    auto s2 = startBuildThread(o);
    while (!s2->finished) {}
    CHECK(s2->result.ok && s2->result.filesWritten == 4);
    CHECK(fs::exists(packs / "full-pack" / "GJ_GameSheet-uhd.png"));

    // --- erro claro quando nao ha texturas
    BuildOptions empty = o;
    empty.resourcesDir = root / "nao_existe";
    empty.theme.name = "Vazio";
    auto r = buildPack(empty);
    CHECK(!r.ok && !r.error.empty());

    // --- nome malicioso nao escapa da pasta de packs
    BuildOptions evil = o;
    evil.theme.name = "../../../evil";
    auto re = buildPack(evil);
    CHECK(re.ok);
    CHECK(re.packDir.parent_path() == packs);
    CHECK(!fs::exists(root / "evil"));

    fs::remove_all(root);
    if (g_fail == 0) std::printf("OK: PackBuilder ponta a ponta\n");
    return g_fail ? 1 : 0;
}
