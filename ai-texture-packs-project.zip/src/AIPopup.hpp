#pragma once

#include "PackBuilder.hpp"
#include "ThemeClient.hpp"

#include <Geode/Geode.hpp>

class AIPopup : public geode::Popup {
public:
    static AIPopup* create();

protected:
    bool init();

    void onGenerate(cocos2d::CCObject*);
    void onSettings(cocos2d::CCObject*);

    void gotTheme(geode::Result<aitp::Theme> theme);
    void gotImage(aitp::Theme theme, geode::Result<aitp::Image> image);
    void startBuild(aitp::Theme theme, std::optional<aitp::Image> image);
    void poll(float dt);

    void setStatus(std::string const& text, bool error = false);
    void setBusy(bool busy);

    geode::TextInput* m_input = nullptr;
    cocos2d::CCLabelBMFont* m_status = nullptr;
    CCMenuItemSpriteExtra* m_generateBtn = nullptr;
    aitp::WebHolder m_themeTask;
    aitp::WebHolder m_imageTask;
    std::shared_ptr<aitp::JobState> m_job;
    aitp::ApiConfig m_cfg;
};
