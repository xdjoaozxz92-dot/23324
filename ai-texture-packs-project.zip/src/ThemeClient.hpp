#pragma once

#include "ImageOps.hpp"

#include <Geode/Geode.hpp>
#include <Geode/utils/async.hpp>
#include <Geode/utils/web.hpp>

#include <string>

namespace aitp {

struct ApiConfig {
    std::string provider;   // "anthropic" | "openai"
    std::string apiKey;
    std::string baseUrl;    // vazio = padrao do provedor
    std::string textModel;  // vazio = padrao do provedor
    std::string imageModel;
    bool useImages = false; // so vale para "openai"
};

ApiConfig loadApiConfig();

using WebHolder = geode::async::TaskHolder<geode::utils::web::WebResponse>;

// Pede um tema a partir da descricao do usuario. `done` roda na main thread.
void requestTheme(
    WebHolder& holder, ApiConfig const& cfg, std::string const& userPrompt,
    geode::Function<void(geode::Result<Theme>)> done
);

// Pede UMA imagem (so provedor "openai"). `done` roda na main thread.
void requestImage(
    WebHolder& holder, ApiConfig const& cfg, std::string const& imagePrompt,
    geode::Function<void(geode::Result<Image>)> done
);

// Extrai o objeto {...} de uma resposta de texto e converte em Theme.
// (separado para ser facil de testar/depurar)
geode::Result<Theme> parseThemeText(std::string const& text);

} // namespace aitp
