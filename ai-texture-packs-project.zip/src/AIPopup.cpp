#include "AIPopup.hpp"

using namespace geode::prelude;

AIPopup* AIPopup::create() {
    auto ret = new AIPopup();
    if (ret->init()) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

bool AIPopup::init() {
    if (!Popup::init(380.f, 250.f)) return false;
    this->setTitle("AI Texture Pack Generator");

    auto hint = CCLabelBMFont::create("Descreva o tema do seu texture pack:", "chatFont.fnt");
    hint->setScale(0.75f);
    m_mainLayer->addChildAtPosition(hint, Anchor::Top, {0.f, -50.f});

    m_input = TextInput::create(320.f, "ex: cyberpunk neon roxo e rosa", "chatFont.fnt");
    m_input->setMaxCharCount(120);
    m_mainLayer->addChildAtPosition(m_input, Anchor::Top, {0.f, -85.f});

    m_status = CCLabelBMFont::create("Pronto.", "chatFont.fnt");
    m_status->setScale(0.7f);
    m_status->setWidth(340.f);
    m_mainLayer->addChildAtPosition(m_status, Anchor::Center, {0.f, -15.f});

    auto genSpr = ButtonSprite::create("Gerar pack");
    m_generateBtn = CCMenuItemSpriteExtra::create(genSpr, this, menu_selector(AIPopup::onGenerate));
    m_buttonMenu->addChildAtPosition(m_generateBtn, Anchor::Bottom, {0.f, 35.f});

    auto setSpr = CCSprite::createWithSpriteFrameName("GJ_optionsBtn02_001.png");
    setSpr->setScale(0.6f);
    auto setBtn = CCMenuItemSpriteExtra::create(setSpr, this, menu_selector(AIPopup::onSettings));
    m_buttonMenu->addChildAtPosition(setBtn, Anchor::BottomRight, {-25.f, 25.f});

    return true;
}

void AIPopup::onSettings(CCObject*) {
    openSettingsPopup(Mod::get(), false);
}

void AIPopup::setStatus(std::string const& text, bool error) {
    m_status->setString(text.c_str());
    m_status->setColor(error ? ccColor3B{255, 110, 110} : ccColor3B{255, 255, 255});
}

void AIPopup::setBusy(bool busy) {
    m_generateBtn->setEnabled(!busy);
    m_generateBtn->setOpacity(busy ? 120 : 255);
    m_input->setEnabled(!busy);
}

void AIPopup::onGenerate(CCObject*) {
    std::string prompt = m_input->getString();
    if (prompt.size() < 3) {
        setStatus("Escreva pelo menos algumas palavras sobre o tema.", true);
        return;
    }
    m_cfg = aitp::loadApiConfig();
    if (m_cfg.apiKey.empty()) {
        setStatus("Falta a chave de API. Toque na engrenagem.", true);
        return;
    }
    setBusy(true);
    setStatus("Pedindo o tema para a IA...");
    aitp::requestTheme(m_themeTask, m_cfg, prompt, [this](Result<aitp::Theme> r) {
        this->gotTheme(std::move(r));
    });
}

void AIPopup::gotTheme(Result<aitp::Theme> theme) {
    if (theme.isErr()) {
        setBusy(false);
        setStatus("Erro: " + theme.unwrapErr(), true);
        return;
    }
    auto t = theme.unwrap();
    bool wantImage = m_cfg.useImages && m_cfg.provider == "openai" && !t.imagePrompt.empty();
    if (!wantImage) {
        this->startBuild(std::move(t), std::nullopt);
        return;
    }
    setStatus("Tema \"" + t.name + "\" pronto. Gerando imagem de fundo...");
    auto prompt = t.imagePrompt;
    aitp::requestImage(m_imageTask, m_cfg, prompt, [this, t = std::move(t)](Result<aitp::Image> img) mutable {
        this->gotImage(std::move(t), std::move(img));
    });
}

void AIPopup::gotImage(aitp::Theme theme, Result<aitp::Image> image) {
    if (image.isErr()) {
        // a imagem e opcional: segue so com a recoloracao
        log::warn("falha na imagem de IA: {}", image.unwrapErr());
        this->startBuild(std::move(theme), std::nullopt);
        return;
    }
    this->startBuild(std::move(theme), image.unwrap());
}

void AIPopup::startBuild(aitp::Theme theme, std::optional<aitp::Image> image) {
    aitp::BuildOptions opts;
    opts.theme = std::move(theme);
    opts.aiImage = std::move(image);
    opts.full = Mod::get()->getSettingValue<bool>("scope-full");
    opts.resourcesDir = dirs::getResourcesDir();
    opts.packsDir = dirs::getModConfigDir() / "geode.texture-loader" / "packs";

    setStatus("Gerando texturas...");
    m_job = aitp::startBuildThread(std::move(opts));
    this->schedule(schedule_selector(AIPopup::poll), 0.15f);
}

void AIPopup::poll(float) {
    if (!m_job) return;
    if (!m_job->finished) {
        int pct = static_cast<int>(m_job->progress.load() * 100.f);
        setStatus(fmt::format("{}% - {}", pct, m_job->getStatus()));
        return;
    }
    this->unschedule(schedule_selector(AIPopup::poll));
    setBusy(false);

    auto const& r = m_job->result;
    if (!r.ok) {
        setStatus("Erro: " + r.error, true);
    } else {
        setStatus(fmt::format("Pronto! {} arquivos.", r.filesWritten));
        std::string msg = fmt::format(
            "Pack criado em:\n<cy>{}</c>\n\n"
            "Agora abra o <cg>Texture Loader</c> no menu principal, arraste o pack para a "
            "direita e toque em <cg>Apply</c>.",
            r.packDir.string()
        );
        if (r.filesFailed > 0) {
            msg += fmt::format("\n\n<cr>{} arquivo(s) falharam e foram ignorados.</c>", r.filesFailed);
        }
        FLAlertLayer::create("Texture Pack criado", msg, "OK")->show();
    }
    m_job.reset();
}
