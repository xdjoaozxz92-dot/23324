#include "ImageOps.hpp"

#include "lodepng.h"

#include <algorithm>
#include <cctype>
#include <cmath>

namespace aitp {

namespace {

float clamp01(float v) { return v < 0.f ? 0.f : (v > 1.f ? 1.f : v); }

int hexVal(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

void rgbToHsv(float r, float g, float b, float& h, float& s, float& v) {
    float mx = std::max({r, g, b});
    float mn = std::min({r, g, b});
    float d = mx - mn;
    v = mx;
    s = mx <= 0.f ? 0.f : d / mx;
    if (d <= 1e-6f) {
        h = 0.f;
    } else if (mx == r) {
        h = 60.f * std::fmod((g - b) / d, 6.f);
    } else if (mx == g) {
        h = 60.f * (((b - r) / d) + 2.f);
    } else {
        h = 60.f * (((r - g) / d) + 4.f);
    }
    if (h < 0.f) h += 360.f;
}

void hsvToRgb(float h, float s, float v, float& r, float& g, float& b) {
    float c = v * s;
    float hp = std::fmod(h, 360.f) / 60.f;
    float x = c * (1.f - std::fabs(std::fmod(hp, 2.f) - 1.f));
    float r1 = 0, g1 = 0, b1 = 0;
    if (hp < 1) { r1 = c; g1 = x; }
    else if (hp < 2) { r1 = x; g1 = c; }
    else if (hp < 3) { g1 = c; b1 = x; }
    else if (hp < 4) { g1 = x; b1 = c; }
    else if (hp < 5) { r1 = x; b1 = c; }
    else { r1 = c; b1 = x; }
    float m = v - c;
    r = r1 + m;
    g = g1 + m;
    b = b1 + m;
}

uint8_t toByte(float v) {
    return static_cast<uint8_t>(std::lround(clamp01(v) * 255.f));
}

// amostra bilinear de um pixel (x,y em coordenadas de pixel, centro = +0.5)
void sampleBilinear(Image const& src, float fx, float fy, float out[4]) {
    fx = std::clamp(fx, 0.f, float(src.w - 1));
    fy = std::clamp(fy, 0.f, float(src.h - 1));
    unsigned x0 = static_cast<unsigned>(fx), y0 = static_cast<unsigned>(fy);
    unsigned x1 = std::min(x0 + 1, src.w - 1), y1 = std::min(y0 + 1, src.h - 1);
    float tx = fx - x0, ty = fy - y0;
    auto at = [&](unsigned x, unsigned y, int c) {
        return float(src.px[(size_t(y) * src.w + x) * 4 + c]);
    };
    for (int c = 0; c < 4; ++c) {
        float top = at(x0, y0, c) * (1 - tx) + at(x1, y0, c) * tx;
        float bot = at(x0, y1, c) * (1 - tx) + at(x1, y1, c) * tx;
        out[c] = top * (1 - ty) + bot * ty;
    }
}

} // namespace

bool parseHexColor(std::string_view s, RGB& out) {
    if (!s.empty() && s.front() == '#') s.remove_prefix(1);
    if (s.size() == 3) {
        int a = hexVal(s[0]), b = hexVal(s[1]), c = hexVal(s[2]);
        if (a < 0 || b < 0 || c < 0) return false;
        out = {uint8_t(a * 17), uint8_t(b * 17), uint8_t(c * 17)};
        return true;
    }
    if (s.size() == 6) {
        int v[6];
        for (int i = 0; i < 6; ++i) {
            v[i] = hexVal(s[i]);
            if (v[i] < 0) return false;
        }
        out = {uint8_t(v[0] * 16 + v[1]), uint8_t(v[2] * 16 + v[3]), uint8_t(v[4] * 16 + v[5])};
        return true;
    }
    return false;
}

void clampTheme(Theme& t) {
    auto fin = [](float v, float fallback) { return std::isfinite(v) ? v : fallback; };
    t.hueShift = std::clamp(fin(t.hueShift, 0.f), -180.f, 180.f);
    t.saturation = std::clamp(fin(t.saturation, 1.f), 0.f, 2.f);
    t.brightness = std::clamp(fin(t.brightness, 1.f), 0.4f, 1.6f);
    t.mix = std::clamp(fin(t.mix, 0.35f), 0.f, 1.f);
    if (t.palette.size() > 6) t.palette.resize(6);
    if (t.name.empty()) t.name = "AI Pack";
    if (t.name.size() > 40) t.name.resize(40);
}

RGB sampleGradient(std::vector<RGB> const& p, float t) {
    if (p.empty()) return {};
    if (p.size() == 1) return p[0];
    t = clamp01(t) * float(p.size() - 1);
    size_t i = static_cast<size_t>(t);
    if (i >= p.size() - 1) return p.back();
    float f = t - float(i);
    auto mixc = [&](uint8_t a, uint8_t b) { return uint8_t(std::lround(a + (b - a) * f)); };
    return {mixc(p[i].r, p[i + 1].r), mixc(p[i].g, p[i + 1].g), mixc(p[i].b, p[i + 1].b)};
}

void applyTheme(Image& img, Theme const& theme, float mixScale) {
    if (img.empty()) return;
    float mix = clamp01(theme.mix * mixScale);
    bool useGradient = theme.palette.size() >= 2 && mix > 0.f;
    // pre-calcula uma LUT de 256 entradas do gradiente
    std::vector<RGB> lut;
    if (useGradient) {
        lut.resize(256);
        for (int i = 0; i < 256; ++i) lut[i] = sampleGradient(theme.palette, i / 255.f);
    }
    size_t n = size_t(img.w) * img.h;
    for (size_t i = 0; i < n; ++i) {
        uint8_t* p = &img.px[i * 4];
        if (p[3] == 0) continue;
        float r = p[0] / 255.f, g = p[1] / 255.f, b = p[2] / 255.f;
        float h, s, v;
        rgbToHsv(r, g, b, h, s, v);
        h = std::fmod(h + theme.hueShift + 360.f, 360.f);
        s = clamp01(s * theme.saturation);
        v = clamp01(v * theme.brightness);
        hsvToRgb(h, s, v, r, g, b);
        if (useGradient) {
            float lum = 0.299f * r + 0.587f * g + 0.114f * b;
            RGB m = lut[std::clamp(int(std::lround(lum * 255.f)), 0, 255)];
            r += (m.r / 255.f - r) * mix;
            g += (m.g / 255.f - g) * mix;
            b += (m.b / 255.f - b) * mix;
        }
        p[0] = toByte(r);
        p[1] = toByte(g);
        p[2] = toByte(b);
    }
}

Image resizeBilinear(Image const& src, unsigned w, unsigned h) {
    Image out;
    if (src.empty() || w == 0 || h == 0) return out;
    out.w = w;
    out.h = h;
    out.px.resize(size_t(w) * h * 4);
    float sx = float(src.w) / w, sy = float(src.h) / h;
    for (unsigned y = 0; y < h; ++y) {
        for (unsigned x = 0; x < w; ++x) {
            float c[4];
            sampleBilinear(src, (x + 0.5f) * sx - 0.5f, (y + 0.5f) * sy - 0.5f, c);
            uint8_t* o = &out.px[(size_t(y) * w + x) * 4];
            for (int k = 0; k < 4; ++k) o[k] = uint8_t(std::lround(std::clamp(c[k], 0.f, 255.f)));
        }
    }
    return out;
}

Image resizeCover(Image const& src, unsigned w, unsigned h) {
    Image out;
    if (src.empty() || w == 0 || h == 0) return out;
    float scale = std::max(float(w) / src.w, float(h) / src.h);
    float cropW = w / scale, cropH = h / scale; // regiao da origem usada
    float offX = (src.w - cropW) * 0.5f, offY = (src.h - cropH) * 0.5f;
    out.w = w;
    out.h = h;
    out.px.resize(size_t(w) * h * 4);
    for (unsigned y = 0; y < h; ++y) {
        for (unsigned x = 0; x < w; ++x) {
            float c[4];
            sampleBilinear(src, offX + (x + 0.5f) / scale - 0.5f, offY + (y + 0.5f) / scale - 0.5f, c);
            uint8_t* o = &out.px[(size_t(y) * w + x) * 4];
            for (int k = 0; k < 4; ++k) o[k] = uint8_t(std::lround(std::clamp(c[k], 0.f, 255.f)));
        }
    }
    return out;
}

void blendImage(Image& dst, Image const& src, float amount) {
    if (dst.empty() || src.empty() || dst.w != src.w || dst.h != src.h) return;
    amount = clamp01(amount);
    size_t n = size_t(dst.w) * dst.h;
    for (size_t i = 0; i < n; ++i) {
        uint8_t* d = &dst.px[i * 4];
        uint8_t const* s = &src.px[i * 4];
        if (d[3] == 0) continue;
        for (int k = 0; k < 3; ++k) d[k] = uint8_t(std::lround(d[k] + (s[k] - d[k]) * amount));
    }
}

Image makeGradientIcon(Theme const& theme, unsigned size) {
    Image out;
    out.w = out.h = size;
    out.px.resize(size_t(size) * size * 4);
    std::vector<RGB> pal = theme.palette;
    if (pal.size() < 2) pal = {{20, 20, 40}, {90, 140, 255}};
    for (unsigned y = 0; y < size; ++y) {
        for (unsigned x = 0; x < size; ++x) {
            float t = (float(x) + float(y)) / float(2 * (size - 1));
            RGB c = sampleGradient(pal, t);
            bool border = x < 3 || y < 3 || x >= size - 3 || y >= size - 3;
            uint8_t* o = &out.px[(size_t(y) * size + x) * 4];
            o[0] = border ? 255 : c.r;
            o[1] = border ? 255 : c.g;
            o[2] = border ? 255 : c.b;
            o[3] = 255;
        }
    }
    return out;
}

std::vector<uint8_t> base64Decode(std::string_view in) {
    static const std::string_view kAlpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    int8_t rev[256];
    std::fill(std::begin(rev), std::end(rev), int8_t(-1));
    for (size_t i = 0; i < kAlpha.size(); ++i) rev[uint8_t(kAlpha[i])] = int8_t(i);
    rev[uint8_t('-')] = 62; // variante url-safe
    rev[uint8_t('_')] = 63;
    std::vector<uint8_t> out;
    out.reserve(in.size() * 3 / 4);
    uint32_t acc = 0;
    int bits = 0;
    for (char ch : in) {
        if (ch == '=') break;
        int v = rev[uint8_t(ch)];
        if (v < 0) continue; // ignora espacos e quebras de linha
        acc = (acc << 6) | uint32_t(v);
        bits += 6;
        if (bits >= 8) {
            bits -= 8;
            out.push_back(uint8_t((acc >> bits) & 0xFF));
        }
    }
    return out;
}

bool decodePng(uint8_t const* data, size_t size, Image& out, std::string& err) {
    std::vector<unsigned char> raw;
    unsigned w = 0, h = 0;
    unsigned e = lodepng::decode(raw, w, h, data, size, LCT_RGBA, 8);
    if (e) {
        err = lodepng_error_text(e);
        return false;
    }
    out.w = w;
    out.h = h;
    out.px = std::move(raw);
    return true;
}

bool encodePng(Image const& img, std::vector<uint8_t>& out, std::string& err) {
    if (img.empty()) {
        err = "imagem vazia";
        return false;
    }
    unsigned e = lodepng::encode(out, img.px, img.w, img.h, LCT_RGBA, 8);
    if (e) {
        err = lodepng_error_text(e);
        return false;
    }
    return true;
}

std::string slugify(std::string_view in) {
    std::string out;
    bool lastDash = true;
    for (char ch : in) {
        unsigned char c = static_cast<unsigned char>(ch);
        if (std::isalnum(c) && c < 128) {
            out.push_back(char(std::tolower(c)));
            lastDash = false;
        } else if (!lastDash) {
            out.push_back('-');
            lastDash = true;
        }
    }
    while (!out.empty() && out.back() == '-') out.pop_back();
    if (out.empty()) out = "ai-pack";
    if (out.size() > 32) out.resize(32);
    return out;
}

std::string jsonEscape(std::string_view in) {
    static const char* hex = "0123456789abcdef";
    std::string out;
    out.reserve(in.size() + 8);
    for (char ch : in) {
        unsigned char c = static_cast<unsigned char>(ch);
        switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (c < 0x20) {
                    out += "\\u00";
                    out.push_back(hex[c >> 4]);
                    out.push_back(hex[c & 15]);
                } else {
                    out.push_back(ch);
                }
        }
    }
    return out;
}

} // namespace aitp
