// AI Texture Pack Generator - nucleo de processamento de imagem.
// IMPORTANTE: este arquivo NAO inclui nada do Geode, para poder ser testado
// em qualquer compilador (veja tests/test_imageops.cpp).
#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <string_view>
#include <vector>

namespace aitp {

struct RGB {
    uint8_t r = 0, g = 0, b = 0;
};

struct Image {
    unsigned w = 0, h = 0;
    std::vector<uint8_t> px; // RGBA, 8 bits por canal, alpha "straight"
    bool empty() const { return w == 0 || h == 0 || px.size() != size_t(w) * h * 4; }
};

// Tema devolvido pela IA (ou default local).
struct Theme {
    std::string name = "AI Pack";
    std::vector<RGB> palette;   // do mais escuro ao mais claro (2 a 6 cores)
    float hueShift = 0.f;       // graus, -180..180
    float saturation = 1.f;     // 0..2
    float brightness = 1.f;     // 0.4..1.6
    float mix = 0.35f;          // forca do gradient map, 0..1
    std::string imagePrompt;    // prompt p/ gerador de imagem (opcional)
};

// "#aabbcc", "aabbcc" ou "#abc"
bool parseHexColor(std::string_view s, RGB& out);

// Garante que os numeros da IA estao em faixas seguras.
void clampTheme(Theme& t);

// t em 0..1 percorrendo a paleta igualmente espacada.
RGB sampleGradient(std::vector<RGB> const& palette, float t);

// 1) rotaciona matiz, 2) escala saturacao/brilho, 3) mistura com gradient map
// da luminancia. Pixels com alpha 0 sao ignorados. O alpha nunca muda.
void applyTheme(Image& img, Theme const& theme, float mixScale = 1.f);

// Redimensiona com interpolacao bilinear.
Image resizeBilinear(Image const& src, unsigned w, unsigned h);

// Redimensiona preenchendo todo o w x h (corta o excesso, centralizado).
Image resizeCover(Image const& src, unsigned w, unsigned h);

// dst.rgb = lerp(dst.rgb, src.rgb, amount). Mesmo tamanho. Alpha do dst fica.
void blendImage(Image& dst, Image const& src, float amount);

// Icone quadrado (pack.png) com gradiente diagonal da paleta.
Image makeGradientIcon(Theme const& theme, unsigned size);

std::vector<uint8_t> base64Decode(std::string_view in);

bool decodePng(uint8_t const* data, size_t size, Image& out, std::string& err);
bool encodePng(Image const& img, std::vector<uint8_t>& out, std::string& err);

// "Neon Cyber City!" -> "neon-cyber-city" (so [a-z0-9-], nunca vazio)
std::string slugify(std::string_view in);

// Escapa para dentro de aspas de JSON (sem as aspas externas).
std::string jsonEscape(std::string_view in);

} // namespace aitp
