#include "AIPopup.hpp"

#include <Geode/Geode.hpp>
#include <Geode/modify/MenuLayer.hpp>

using namespace geode::prelude;

class $modify(AIMenuLayer, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) return false;

        auto menu = this->getChildByID("bottom-menu");
        if (!menu) return true; // outro mod mexeu no menu: nao quebra nada

        auto label = CCLabelBMFont::create("AI", "bigFont.fnt");
        label->setScale(0.9f);
        auto spr = CircleButtonSprite::create(label, CircleBaseColor::Pink, CircleBaseSize::Medium);
        auto btn = CCMenuItemSpriteExtra::create(spr, this, menu_selector(AIMenuLayer::onAIPack));
        btn->setID("ai-pack-button"_spr);
        menu->addChild(btn);
        menu->updateLayout();
        return true;
    }

    void onAIPack(CCObject*) {
        if (auto popup = AIPopup::create()) popup->show();
    }
};
