#include "ThemeClient.hpp"

using namespace geode::prelude;

namespace aitp {

namespace {

constexpr char const* kSystemPrompt =
    "You are an art director for Geometry Dash texture packs. The user describes a visual theme. "
    "Reply with ONLY one JSON object (no markdown, no commentary) with exactly these keys: "
    "\"name\" (short pack name, max 30 chars), "
    "\"palette\" (array of 3 to 5 hex colors like \"#1a0b2e\", ordered from darkest to lightest), "
    "\"hue_shift\" (number from -180 to 180, degrees applied to the colors of the existing game art), "
    "\"saturation\" (number 0 to 2, 1 = unchanged), "
    "\"brightness\" (number 0.5 to 1.5, 1 = unchanged), "
    "\"gradient_strength\" (number 0 to 1, how strongly the palette recolors the art), "
    "\"image_prompt\" (one sentence describing a seamless wide background image for the theme; "
    "no text, no logos, no characters, no copyrighted material).";

std::string trimSlash(std::string s) {
    while (!s.empty() && s.back() == '/') s.pop_back();
    return s;
}

std::string shorten(std::string s, size_t n = 160) {
    if (s.size() > n) {
        s.resize(n);
        s += "...";
    }
    return s;
}

std::string httpError(web::WebResponse& res) {
    std::string body = res.string().unwrapOr("");
    return fmt::format("HTTP {}: {}", res.code(), shorten(body));
}

} // namespace

ApiConfig loadApiConfig() {
    auto* mod = Mod::get();
    ApiConfig c;
    c.provider = mod->getSettingValue<std::string>("provider");
    c.apiKey = mod->getSettingValue<std::string>("api-key");
    c.baseUrl = trimSlash(mod->getSettingValue<std::string>("base-url"));
    c.textModel = mod->getSettingValue<std::string>("text-model");
    c.imageModel = mod->getSettingValue<std::string>("image-model");
    c.useImages = mod->getSettingValue<bool>("use-ai-images");
    if (c.provider != "openai") c.provider = "anthropic";
    if (c.textModel.empty()) c.textModel = c.provider == "openai" ? "gpt-4o-mini" : "claude-haiku-5-5";
    if (c.imageModel.empty()) c.imageModel = "gpt-image-1";
    return c;
}

Result<Theme> parseThemeText(std::string const& text) {
    auto a = text.find('{');
    auto b = text.rfind('}');
    if (a == std::string::npos || b == std::string::npos || b <= a) {
        return Err("a IA nao devolveu um JSON valido");
    }
    auto parsed = matjson::parse(text.substr(a, b - a + 1));
    if (parsed.isErr()) {
        return Err("JSON da IA invalido");
    }
    auto v = parsed.unwrap();

    Theme t;
    t.name = v["name"].asString().unwrapOr("AI Pack");
    t.hueShift = static_cast<float>(v["hue_shift"].asDouble().unwrapOr(0.0));
    t.saturation = static_cast<float>(v["saturation"].asDouble().unwrapOr(1.0));
    t.brightness = static_cast<float>(v["brightness"].asDouble().unwrapOr(1.0));
    t.mix = static_cast<float>(v["gradient_strength"].asDouble().unwrapOr(0.35));
    t.imagePrompt = v["image_prompt"].asString().unwrapOr("");

    if (auto arr = v["palette"].asArray(); arr.isOk()) {
        for (auto& item : arr.unwrap()) {
            RGB c;
            if (parseHexColor(item.asString().unwrapOr(""), c)) t.palette.push_back(c);
        }
    }
    if (t.palette.size() < 2) {
        return Err("a IA nao devolveu uma paleta de cores utilizavel");
    }
    clampTheme(t);
    return Ok(std::move(t));
}

void requestTheme(
    WebHolder& holder, ApiConfig const& cfg, std::string const& userPrompt,
    Function<void(Result<Theme>)> done
) {
    web::WebRequest req;
    std::string url;
    std::string body;
    std::string const user = jsonEscape(userPrompt);
    std::string const sys = jsonEscape(kSystemPrompt);

    if (cfg.provider == "openai") {
        url = (cfg.baseUrl.empty() ? "https://api.openai.com/v1" : cfg.baseUrl) + "/chat/completions";
        req.header("Authorization", "Bearer " + cfg.apiKey);
        body = fmt::format(
            R"({{"model":"{}","messages":[{{"role":"system","content":"{}"}},{{"role":"user","content":"{}"}}]}})",
            jsonEscape(cfg.textModel), sys, user
        );
    } else {
        url = (cfg.baseUrl.empty() ? "https://api.anthropic.com" : cfg.baseUrl) + "/v1/messages";
        req.header("x-api-key", cfg.apiKey);
        req.header("anthropic-version", "2023-06-01");
        body = fmt::format(
            R"({{"model":"{}","max_tokens":700,"system":"{}","messages":[{{"role":"user","content":"{}"}}]}})",
            jsonEscape(cfg.textModel), sys, user
        );
    }
    req.header("Content-Type", "application/json");
    req.bodyString(body);

    bool const openai = cfg.provider == "openai";
    holder.spawn(
        req.post(url),
        [openai, done = std::move(done)](web::WebResponse res) mutable {
            if (!res.ok()) {
                done(Err(httpError(res)));
                return;
            }
            auto json = res.json();
            if (json.isErr()) {
                done(Err("resposta da API nao e JSON"));
                return;
            }
            auto v = json.unwrap();
            std::string text = openai
                ? v["choices"][0]["message"]["content"].asString().unwrapOr("")
                : v["content"][0]["text"].asString().unwrapOr("");
            done(parseThemeText(text));
        }
    );
}

void requestImage(
    WebHolder& holder, ApiConfig const& cfg, std::string const& imagePrompt,
    Function<void(Result<Image>)> done
) {
    if (cfg.provider != "openai") {
        // Nao ha geracao de imagem no provedor "anthropic".
        done(Err("geracao de imagem requer o provedor openai"));
        return;
    }
    web::WebRequest req;
    std::string url = (cfg.baseUrl.empty() ? "https://api.openai.com/v1" : cfg.baseUrl) + "/images/generations";
    req.header("Authorization", "Bearer " + cfg.apiKey);
    req.header("Content-Type", "application/json");

    // dall-e-* precisa pedir b64_json explicitamente; gpt-image-* ja devolve base64.
    bool const dalle = cfg.imageModel.rfind("dall-e", 0) == 0;
    std::string prompt = imagePrompt + ", seamless wide background, no text, no watermark";
    req.bodyString(fmt::format(
        R"({{"model":"{}","prompt":"{}","n":1,"size":"1024x1024"{}}})",
        jsonEscape(cfg.imageModel), jsonEscape(prompt),
        dalle ? R"(,"response_format":"b64_json")" : ""
    ));

    holder.spawn(
        req.post(url),
        [done = std::move(done)](web::WebResponse res) mutable {
            if (!res.ok()) {
                done(Err(httpError(res)));
                return;
            }
            auto json = res.json();
            if (json.isErr()) {
                done(Err("resposta de imagem nao e JSON"));
                return;
            }
            auto v = json.unwrap();
            std::string b64 = v["data"][0]["b64_json"].asString().unwrapOr("");
            if (b64.empty()) {
                done(Err("a API nao devolveu b64_json"));
                return;
            }
            auto bytes = base64Decode(b64);
            Image img;
            std::string err;
            if (!decodePng(bytes.data(), bytes.size(), img, err)) {
                done(Err("imagem invalida (esperado PNG): " + err));
                return;
            }
            done(Ok(std::move(img)));
        }
    );
}

} // namespace aitp
