#include "PackBuilder.hpp"

#include <cstdio>
#include <fstream>
#include <thread>

namespace fs = std::filesystem;

namespace aitp {

namespace {

bool readFile(fs::path const& p, std::vector<uint8_t>& out) {
    std::ifstream f(p, std::ios::binary | std::ios::ate);
    if (!f) return false;
    auto size = f.tellg();
    if (size <= 0) return false;
    out.resize(static_cast<size_t>(size));
    f.seekg(0);
    return static_cast<bool>(f.read(reinterpret_cast<char*>(out.data()), size));
}

bool writeFile(fs::path const& p, uint8_t const* data, size_t size) {
    std::ofstream f(p, std::ios::binary | std::ios::trunc);
    if (!f) return false;
    f.write(reinterpret_cast<char const*>(data), static_cast<std::streamsize>(size));
    return static_cast<bool>(f);
}

bool startsWith(std::string const& s, char const* prefix) {
    return s.rfind(prefix, 0) == 0;
}

std::string two(int n) {
    char buf[8];
    std::snprintf(buf, sizeof(buf), "%02d", n);
    return buf;
}

} // namespace

std::vector<std::string> textureStems(bool full) {
    std::vector<std::string> v;
    v.push_back("GJ_gradientBG");
    for (int i = 1; i <= 20; ++i) v.push_back("game_bg_" + two(i) + "_001");
    for (int i = 1; i <= 10; ++i) v.push_back("groundSquare_" + two(i) + "_001");
    if (full) {
        for (char const* s : {"GJ_GameSheet", "GJ_GameSheet02", "GJ_GameSheet03", "GJ_GameSheet04",
                              "GJ_GameSheetGlow", "GJ_LaunchSheet"}) {
            v.push_back(s);
        }
    }
    return v;
}

BuildResult buildPack(BuildOptions const& opts, JobState* state) {
    BuildResult res;
    auto status = [&](std::string s) {
        if (state) state->setStatus(std::move(s));
    };
    auto progress = [&](float p) {
        if (state) state->progress = p;
    };

    Theme theme = opts.theme;
    clampTheme(theme);

    std::string slug = slugify(theme.name);
    fs::path packDir = opts.packsDir / slug;
    std::error_code ec;
    fs::create_directories(packDir, ec);
    if (ec) {
        res.error = "nao consegui criar a pasta do pack: " + ec.message();
        return res;
    }
    res.packDir = packDir;

    // so tenta qualidades que existem; "" = baixa qualidade (sem sufixo)
    static char const* const kSuffix[] = {"-uhd", "-hd", ""};
    auto stems = textureStems(opts.full);

    // 1) descobre quais arquivos existem (para a barra de progresso ser honesta)
    struct Job {
        std::string stem;
        std::string fileName;
    };
    std::vector<Job> jobs;
    for (auto const& stem : stems) {
        for (char const* suf : kSuffix) {
            std::string name = stem + suf + ".png";
            if (fs::exists(opts.resourcesDir / name, ec)) jobs.push_back({stem, name});
        }
    }
    if (jobs.empty()) {
        res.error = "nenhuma textura base encontrada em " + opts.resourcesDir.string();
        return res;
    }

    // 2) processa
    size_t index = 0;
    for (auto const& job : jobs) {
        status("Processando " + job.fileName);
        std::vector<uint8_t> raw;
        Image img;
        std::string err;
        bool ok = readFile(opts.resourcesDir / job.fileName, raw) &&
                  decodePng(raw.data(), raw.size(), img, err);
        if (ok) {
            bool isSheet = startsWith(job.stem, "GJ_") && job.stem.find("Sheet") != std::string::npos;
            bool isBackground = startsWith(job.stem, "game_bg_") || job.stem == "GJ_gradientBG";
            applyTheme(img, theme, isSheet ? 0.6f : 1.f);
            if (isBackground && opts.aiImage && !opts.aiImage->empty()) {
                Image scaled = resizeCover(*opts.aiImage, img.w, img.h);
                blendImage(img, scaled, 0.75f);
            }
            std::vector<uint8_t> png;
            ok = encodePng(img, png, err) && writeFile(packDir / job.fileName, png.data(), png.size());
        }
        if (ok) ++res.filesWritten;
        else ++res.filesFailed;
        ++index;
        progress(float(index) / float(jobs.size()));
    }
    if (res.filesWritten == 0) {
        res.error = "todos os arquivos falharam ao processar";
        return res;
    }

    // 3) pack.png (icone) e pack.json (Texture Loader)
    status("Escrevendo pack.json");
    Image icon = (opts.aiImage && !opts.aiImage->empty()) ? resizeCover(*opts.aiImage, 128, 128)
                                                          : makeGradientIcon(theme, 128);
    std::vector<uint8_t> iconPng;
    std::string err;
    if (encodePng(icon, iconPng, err)) writeFile(packDir / "pack.png", iconPng.data(), iconPng.size());

    std::string json = "{\n"
                       "  \"textureldr\": \"1.5.0\",\n"
                       "  \"name\": \"" + jsonEscape(theme.name) + "\",\n"
                       "  \"id\": \"aimodgen." + slug + "\",\n"
                       "  \"version\": \"1.0.0\",\n"
                       "  \"author\": \"AI Texture Pack Generator\"\n"
                       "}\n";
    if (!writeFile(packDir / "pack.json", reinterpret_cast<uint8_t const*>(json.data()), json.size())) {
        res.error = "falha ao escrever pack.json";
        return res;
    }

    res.ok = true;
    return res;
}

std::shared_ptr<JobState> startBuildThread(BuildOptions opts) {
    auto state = std::make_shared<JobState>();
    std::thread([state, opts = std::move(opts)]() mutable {
        BuildResult r;
        try {
            r = buildPack(opts, state.get());
        } catch (std::exception const& e) {
            r.error = std::string("erro inesperado: ") + e.what();
        } catch (...) {
            r.error = "erro inesperado";
        }
        state->result = std::move(r);
        state->progress = 1.f;
        state->finished = true; // por ultimo: a UI so le `result` depois disso
    }).detach();
    return state;
}

} // namespace aitp
