#pragma once

// Sem includes do Geode aqui: o builder so usa std::filesystem + ImageOps,
// entao da para testar em qualquer compilador (tests/test_packbuilder.cpp).

#include "ImageOps.hpp"

#include <atomic>
#include <filesystem>
#include <memory>
#include <mutex>
#include <optional>
#include <string>
#include <vector>

namespace aitp {

struct BuildOptions {
    Theme theme;
    std::optional<Image> aiImage;          // imagem gerada pela IA (opcional)
    bool full = false;                     // true = inclui spritesheets
    std::filesystem::path resourcesDir;    // <GD>/Resources (texturas originais)
    std::filesystem::path packsDir;        // .../geode.texture-loader/packs
};

struct BuildResult {
    bool ok = false;
    std::string error;
    std::filesystem::path packDir;
    int filesWritten = 0;
    int filesFailed = 0;
};

// Estado compartilhado entre a thread de trabalho e a UI (a UI so le).
struct JobState {
    std::atomic<float> progress{0.f};
    std::atomic<bool> finished{false};
    std::mutex mutex;
    std::string status;   // protegido por mutex
    BuildResult result;   // valido quando finished == true

    void setStatus(std::string s) {
        std::lock_guard lock(mutex);
        status = std::move(s);
    }
    std::string getStatus() {
        std::lock_guard lock(mutex);
        return status;
    }
};

// Lista (sem sufixo de qualidade/extensao) das texturas que o pack tenta cobrir.
std::vector<std::string> textureStems(bool full);

// Roda tudo de forma sincrona (usado pela thread e pelos testes).
BuildResult buildPack(BuildOptions const& opts, JobState* state = nullptr);

// Dispara buildPack numa std::thread desacoplada.
std::shared_ptr<JobState> startBuildThread(BuildOptions opts);

} // namespace aitp
