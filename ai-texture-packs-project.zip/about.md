# AI Texture Pack Generator

Crie **Texture Packs** para Geometry Dash descrevendo o tema em uma frase.

1. No menu principal, toque no botão rosa **AI**.
2. Escreva o tema (ex.: *cyberpunk neon roxo e rosa*).
3. A IA escolhe paleta, matiz, saturação e brilho; o mod recolore as texturas do jogo e salva um pack pronto para o **Texture Loader**.

Configure a chave de API nas configurações do mod. Com o provedor `openai` e a opção de imagem ligada, o mod também gera uma imagem de fundo e a mistura nos backgrounds.
