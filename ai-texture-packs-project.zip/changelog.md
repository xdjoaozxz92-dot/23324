# v0.1.0
- Primeira versão: botão AI no menu, tema gerado por IA (Anthropic ou OpenAI-compatível), recoloração de fundos/chão/menu e, opcionalmente, spritesheets.
- Imagem de fundo opcional via provedor OpenAI.
- Gera pack.json + pack.png para o Texture Loader.
